-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: laboratory_test_management
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anti_slip_test_data`
--

DROP TABLE IF EXISTS `anti_slip_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anti_slip_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `humidity` decimal(5,2) NOT NULL,
  `friction_coefficient` decimal(6,4) NOT NULL,
  `slip_resistance` decimal(8,2) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `anti_slip_test_data_test_task_id_665b1bb3_fk_test_tasks_id` (`test_task_id`),
  KEY `anti_slip_test_data_tester_id_9dfe54de_fk_users_id` (`tester_id`),
  CONSTRAINT `anti_slip_test_data_test_task_id_665b1bb3_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `anti_slip_test_data_tester_id_9dfe54de_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anti_slip_test_data`
--

LOCK TABLES `anti_slip_test_data` WRITE;
/*!40000 ALTER TABLE `anti_slip_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `anti_slip_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changes` json DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` char(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `success` tinyint(1) NOT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_752b0e2b_fk_users_id` (`user_id`),
  CONSTRAINT `audit_logs_user_id_752b0e2b_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add Token',6,'add_token'),(22,'Can change Token',6,'change_token'),(23,'Can delete Token',6,'delete_token'),(24,'Can view Token',6,'view_token'),(25,'Can add token',7,'add_tokenproxy'),(26,'Can change token',7,'change_tokenproxy'),(27,'Can delete token',7,'delete_tokenproxy'),(28,'Can view token',7,'view_tokenproxy'),(29,'Can add group object permission',8,'add_groupobjectpermission'),(30,'Can change group object permission',8,'change_groupobjectpermission'),(31,'Can delete group object permission',8,'delete_groupobjectpermission'),(32,'Can view group object permission',8,'view_groupobjectpermission'),(33,'Can add user object permission',9,'add_userobjectpermission'),(34,'Can change user object permission',9,'change_userobjectpermission'),(35,'Can delete user object permission',9,'delete_userobjectpermission'),(36,'Can view user object permission',9,'view_userobjectpermission'),(37,'Can add crontab',10,'add_crontabschedule'),(38,'Can change crontab',10,'change_crontabschedule'),(39,'Can delete crontab',10,'delete_crontabschedule'),(40,'Can view crontab',10,'view_crontabschedule'),(41,'Can add interval',11,'add_intervalschedule'),(42,'Can change interval',11,'change_intervalschedule'),(43,'Can delete interval',11,'delete_intervalschedule'),(44,'Can view interval',11,'view_intervalschedule'),(45,'Can add periodic task',12,'add_periodictask'),(46,'Can change periodic task',12,'change_periodictask'),(47,'Can delete periodic task',12,'delete_periodictask'),(48,'Can view periodic task',12,'view_periodictask'),(49,'Can add periodic tasks',13,'add_periodictasks'),(50,'Can change periodic tasks',13,'change_periodictasks'),(51,'Can delete periodic tasks',13,'delete_periodictasks'),(52,'Can view periodic tasks',13,'view_periodictasks'),(53,'Can add solar event',14,'add_solarschedule'),(54,'Can change solar event',14,'change_solarschedule'),(55,'Can delete solar event',14,'delete_solarschedule'),(56,'Can view solar event',14,'view_solarschedule'),(57,'Can add clocked',15,'add_clockedschedule'),(58,'Can change clocked',15,'change_clockedschedule'),(59,'Can delete clocked',15,'delete_clockedschedule'),(60,'Can view clocked',15,'view_clockedschedule'),(61,'Can add task result',16,'add_taskresult'),(62,'Can change task result',16,'change_taskresult'),(63,'Can delete task result',16,'delete_taskresult'),(64,'Can view task result',16,'view_taskresult'),(65,'Can add chord counter',17,'add_chordcounter'),(66,'Can change chord counter',17,'change_chordcounter'),(67,'Can delete chord counter',17,'delete_chordcounter'),(68,'Can view chord counter',17,'view_chordcounter'),(69,'Can add group result',18,'add_groupresult'),(70,'Can change group result',18,'change_groupresult'),(71,'Can delete group result',18,'delete_groupresult'),(72,'Can view group result',18,'view_groupresult'),(73,'Can add 部门',19,'add_department'),(74,'Can change 部门',19,'change_department'),(75,'Can delete 部门',19,'delete_department'),(76,'Can view 部门',19,'view_department'),(77,'Can add 用户',20,'add_user'),(78,'Can change 用户',20,'change_user'),(79,'Can delete 用户',20,'delete_user'),(80,'Can view 用户',20,'view_user'),(81,'Can add 优先级类型',21,'add_prioritytype'),(82,'Can change 优先级类型',21,'change_prioritytype'),(83,'Can delete 优先级类型',21,'delete_prioritytype'),(84,'Can view 优先级类型',21,'view_prioritytype'),(85,'Can add 任务状态',22,'add_taskstatus'),(86,'Can change 任务状态',22,'change_taskstatus'),(87,'Can delete 任务状态',22,'delete_taskstatus'),(88,'Can view 任务状态',22,'view_taskstatus'),(89,'Can add 试验任务',23,'add_testtask'),(90,'Can change 试验任务',23,'change_testtask'),(91,'Can delete 试验任务',23,'delete_testtask'),(92,'Can view 试验任务',23,'view_testtask'),(93,'Can add 试验类型',24,'add_testtype'),(94,'Can change 试验类型',24,'change_testtype'),(95,'Can delete 试验类型',24,'delete_testtype'),(96,'Can view 试验类型',24,'view_testtype'),(97,'Can add 子任务',25,'add_subtask'),(98,'Can change 子任务',25,'change_subtask'),(99,'Can delete 子任务',25,'delete_subtask'),(100,'Can view 子任务',25,'view_subtask'),(101,'Can add 子任务数据',26,'add_subtaskdata'),(102,'Can change 子任务数据',26,'change_subtaskdata'),(103,'Can delete 子任务数据',26,'delete_subtaskdata'),(104,'Can view 子任务数据',26,'view_subtaskdata'),(105,'Can add 碟簧试验数据',27,'add_discspringtestdata'),(106,'Can change 碟簧试验数据',27,'change_discspringtestdata'),(107,'Can delete 碟簧试验数据',27,'delete_discspringtestdata'),(108,'Can view 碟簧试验数据',27,'view_discspringtestdata'),(109,'Can add 试验类型字段配置',28,'add_testtypefield'),(110,'Can change 试验类型字段配置',28,'change_testtypefield'),(111,'Can delete 试验类型字段配置',28,'delete_testtypefield'),(112,'Can view 试验类型字段配置',28,'view_testtypefield'),(113,'Can add 通用试验数据',29,'add_generictestdata'),(114,'Can change 通用试验数据',29,'change_generictestdata'),(115,'Can delete 通用试验数据',29,'delete_generictestdata'),(116,'Can view 通用试验数据',29,'view_generictestdata'),(117,'Can add 防滑试验数据',30,'add_antisliptestdata'),(118,'Can change 防滑试验数据',30,'change_antisliptestdata'),(119,'Can delete 防滑试验数据',30,'delete_antisliptestdata'),(120,'Can view 防滑试验数据',30,'view_antisliptestdata'),(121,'Can add 压缩试验数据',31,'add_compressiontestdata'),(122,'Can change 压缩试验数据',31,'change_compressiontestdata'),(123,'Can delete 压缩试验数据',31,'delete_compressiontestdata'),(124,'Can view 压缩试验数据',31,'view_compressiontestdata'),(125,'Can add 腐蚀试验数据',32,'add_corrosiontestdata'),(126,'Can change 腐蚀试验数据',32,'change_corrosiontestdata'),(127,'Can delete 腐蚀试验数据',32,'delete_corrosiontestdata'),(128,'Can view 腐蚀试验数据',32,'view_corrosiontestdata'),(129,'Can add 蠕变试验数据',33,'add_creeptestdata'),(130,'Can change 蠕变试验数据',33,'change_creeptestdata'),(131,'Can delete 蠕变试验数据',33,'delete_creeptestdata'),(132,'Can view 蠕变试验数据',33,'view_creeptestdata'),(133,'Can add 疲劳试验数据',34,'add_fatiguetestdata'),(134,'Can change 疲劳试验数据',34,'change_fatiguetestdata'),(135,'Can delete 疲劳试验数据',34,'delete_fatiguetestdata'),(136,'Can view 疲劳试验数据',34,'view_fatiguetestdata'),(137,'Can add 硬度试验数据',35,'add_hardnesstestdata'),(138,'Can change 硬度试验数据',35,'change_hardnesstestdata'),(139,'Can delete 硬度试验数据',35,'delete_hardnesstestdata'),(140,'Can view 硬度试验数据',35,'view_hardnesstestdata'),(141,'Can add 金属冲击试验数据',36,'add_metalimpacttestdata'),(142,'Can change 金属冲击试验数据',36,'change_metalimpacttestdata'),(143,'Can delete 金属冲击试验数据',36,'delete_metalimpacttestdata'),(144,'Can view 金属冲击试验数据',36,'view_metalimpacttestdata'),(145,'Can add 金属拉伸试验数据',37,'add_metaltensiletestdata'),(146,'Can change 金属拉伸试验数据',37,'change_metaltensiletestdata'),(147,'Can delete 金属拉伸试验数据',37,'delete_metaltensiletestdata'),(148,'Can view 金属拉伸试验数据',37,'view_metaltensiletestdata'),(149,'Can add 设备',38,'add_equipment'),(150,'Can change 设备',38,'change_equipment'),(151,'Can delete 设备',38,'delete_equipment'),(152,'Can view 设备',38,'view_equipment'),(153,'Can add 设备维护记录',39,'add_equipmentmaintenance'),(154,'Can change 设备维护记录',39,'change_equipmentmaintenance'),(155,'Can delete 设备维护记录',39,'delete_equipmentmaintenance'),(156,'Can view 设备维护记录',39,'view_equipmentmaintenance'),(157,'Can add 设备使用记录',40,'add_equipmentusagerecord'),(158,'Can change 设备使用记录',40,'change_equipmentusagerecord'),(159,'Can delete 设备使用记录',40,'delete_equipmentusagerecord'),(160,'Can view 设备使用记录',40,'view_equipmentusagerecord'),(161,'Can add 工装',41,'add_tooling'),(162,'Can change 工装',41,'change_tooling'),(163,'Can delete 工装',41,'delete_tooling'),(164,'Can view 工装',41,'view_tooling'),(165,'Can add 工装维护记录',42,'add_toolingmaintenance'),(166,'Can change 工装维护记录',42,'change_toolingmaintenance'),(167,'Can delete 工装维护记录',42,'delete_toolingmaintenance'),(168,'Can view 工装维护记录',42,'view_toolingmaintenance'),(169,'Can add 工装使用记录',43,'add_toolingusagerecord'),(170,'Can change 工装使用记录',43,'change_toolingusagerecord'),(171,'Can delete 工装使用记录',43,'delete_toolingusagerecord'),(172,'Can view 工装使用记录',43,'view_toolingusagerecord'),(173,'Can add 工具',44,'add_tool'),(174,'Can change 工具',44,'change_tool'),(175,'Can delete 工具',44,'delete_tool'),(176,'Can view 工具',44,'view_tool'),(177,'Can add 工具借用记录',45,'add_toolborrowrecord'),(178,'Can change 工具借用记录',45,'change_toolborrowrecord'),(179,'Can delete 工具借用记录',45,'delete_toolborrowrecord'),(180,'Can view 工具借用记录',45,'view_toolborrowrecord'),(181,'Can add 工具校准记录',46,'add_toolcalibration'),(182,'Can change 工具校准记录',46,'change_toolcalibration'),(183,'Can delete 工具校准记录',46,'delete_toolcalibration'),(184,'Can view 工具校准记录',46,'view_toolcalibration'),(185,'Can add 生成的报表',47,'add_generatedreport'),(186,'Can change 生成的报表',47,'change_generatedreport'),(187,'Can delete 生成的报表',47,'delete_generatedreport'),(188,'Can view 生成的报表',47,'view_generatedreport'),(189,'Can add 报表访问记录',48,'add_reportaccess'),(190,'Can change 报表访问记录',48,'change_reportaccess'),(191,'Can delete 报表访问记录',48,'delete_reportaccess'),(192,'Can view 报表访问记录',48,'view_reportaccess'),(193,'Can add 报表定时任务',49,'add_reportschedule'),(194,'Can change 报表定时任务',49,'change_reportschedule'),(195,'Can delete 报表定时任务',49,'delete_reportschedule'),(196,'Can view 报表定时任务',49,'view_reportschedule'),(197,'Can add 报表模板',50,'add_reporttemplate'),(198,'Can change 报表模板',50,'change_reporttemplate'),(199,'Can delete 报表模板',50,'delete_reporttemplate'),(200,'Can view 报表模板',50,'view_reporttemplate'),(201,'Can add 审计日志',51,'add_auditlog'),(202,'Can change 审计日志',51,'change_auditlog'),(203,'Can delete 审计日志',51,'delete_auditlog'),(204,'Can view 审计日志',51,'view_auditlog'),(205,'Can add 文件上传记录',52,'add_fileupload'),(206,'Can change 文件上传记录',52,'change_fileupload'),(207,'Can delete 文件上传记录',52,'delete_fileupload'),(208,'Can view 文件上传记录',52,'view_fileupload'),(209,'Can add 通知',53,'add_notification'),(210,'Can change 通知',53,'change_notification'),(211,'Can delete 通知',53,'delete_notification'),(212,'Can view 通知',53,'view_notification'),(213,'Can add 系统备份记录',54,'add_systembackup'),(214,'Can change 系统备份记录',54,'change_systembackup'),(215,'Can delete 系统备份记录',54,'delete_systembackup'),(216,'Can view 系统备份记录',54,'view_systembackup'),(217,'Can add 系统配置',55,'add_systemconfig'),(218,'Can change 系统配置',55,'change_systemconfig'),(219,'Can delete 系统配置',55,'delete_systemconfig'),(220,'Can view 系统配置',55,'view_systemconfig'),(221,'Can add 角色',56,'add_role'),(222,'Can change 角色',56,'change_role'),(223,'Can delete 角色',56,'delete_role'),(224,'Can view 角色',56,'view_role'),(225,'Can add 试验任务报告',57,'add_testtaskreport'),(226,'Can change 试验任务报告',57,'change_testtaskreport'),(227,'Can delete 试验任务报告',57,'delete_testtaskreport'),(228,'Can view 试验任务报告',57,'view_testtaskreport'),(229,'Can add 工装报废申请',58,'add_toolingscrapapplication'),(230,'Can change 工装报废申请',58,'change_toolingscrapapplication'),(231,'Can delete 工装报废申请',58,'delete_toolingscrapapplication'),(232,'Can view 工装报废申请',58,'view_toolingscrapapplication'),(233,'Can add 工装预约',59,'add_toolingreservation'),(234,'Can change 工装预约',59,'change_toolingreservation'),(235,'Can delete 工装预约',59,'delete_toolingreservation'),(236,'Can view 工装预约',59,'view_toolingreservation');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compression_test_data`
--

DROP TABLE IF EXISTS `compression_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compression_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `compression_rate` decimal(8,4) NOT NULL,
  `compression_strength` decimal(8,2) NOT NULL,
  `compression_modulus` decimal(10,2) NOT NULL,
  `deformation` decimal(6,2) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compression_test_data_test_task_id_fef6039e_fk_test_tasks_id` (`test_task_id`),
  KEY `compression_test_data_tester_id_e7cabe29_fk_users_id` (`tester_id`),
  CONSTRAINT `compression_test_data_test_task_id_fef6039e_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `compression_test_data_tester_id_e7cabe29_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compression_test_data`
--

LOCK TABLES `compression_test_data` WRITE;
/*!40000 ALTER TABLE `compression_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `compression_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corrosion_test_data`
--

DROP TABLE IF EXISTS `corrosion_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corrosion_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `corrosive_medium` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exposure_time` decimal(10,2) NOT NULL,
  `weight_loss` decimal(8,4) NOT NULL,
  `corrosion_rate` decimal(8,4) NOT NULL,
  `corrosion_depth` decimal(6,3) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `corrosion_test_data_test_task_id_0ec1f6de_fk_test_tasks_id` (`test_task_id`),
  KEY `corrosion_test_data_tester_id_88c0e9c5_fk_users_id` (`tester_id`),
  CONSTRAINT `corrosion_test_data_test_task_id_0ec1f6de_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `corrosion_test_data_tester_id_88c0e9c5_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corrosion_test_data`
--

LOCK TABLES `corrosion_test_data` WRITE;
/*!40000 ALTER TABLE `corrosion_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `corrosion_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creep_test_data`
--

DROP TABLE IF EXISTS `creep_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `creep_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `applied_stress` decimal(8,2) NOT NULL,
  `test_duration` decimal(10,2) NOT NULL,
  `initial_strain` decimal(8,6) NOT NULL,
  `final_strain` decimal(8,6) NOT NULL,
  `creep_rate` decimal(12,8) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creep_test_data_test_task_id_7b377a1a_fk_test_tasks_id` (`test_task_id`),
  KEY `creep_test_data_tester_id_6c6c6dfe_fk_users_id` (`tester_id`),
  CONSTRAINT `creep_test_data_test_task_id_7b377a1a_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `creep_test_data_tester_id_6c6c6dfe_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creep_test_data`
--

LOCK TABLES `creep_test_data` WRITE;
/*!40000 ALTER TABLE `creep_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `creep_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'试验室','LAB','试验室部门','2025-11-27 02:45:52.170286','2025-11-27 02:45:52.170303'),(2,'研发部','R&D','研发部门','2025-11-27 02:45:52.171252','2025-11-27 02:45:52.171266'),(3,'质量部','QA','质量管理部门','2025-11-27 02:45:52.171506','2025-11-27 02:45:52.171515'),(4,'营销部','YS','销售部门','2025-12-16 06:33:43.773835','2025-12-16 06:33:43.773853');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disc_spring_test_data`
--

DROP TABLE IF EXISTS `disc_spring_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disc_spring_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `test_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_total` int NOT NULL,
  `test_quantity` int NOT NULL,
  `supplier` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disc_spring_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `application_date` date NOT NULL,
  `displacement_2mm` decimal(10,2) DEFAULT NULL,
  `displacement_2_5mm` decimal(10,2) DEFAULT NULL,
  `inspector_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_time` datetime(6) NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `subtask_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `test_number` (`test_number`),
  KEY `disc_spring_test_data_subtask_id_fd94f345_fk_sub_tasks_id` (`subtask_id`),
  CONSTRAINT `disc_spring_test_data_subtask_id_fd94f345_fk_sub_tasks_id` FOREIGN KEY (`subtask_id`) REFERENCES `sub_tasks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disc_spring_test_data`
--

LOCK TABLES `disc_spring_test_data` WRITE;
/*!40000 ALTER TABLE `disc_spring_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `disc_spring_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_clockedschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_clockedschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_clockedschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clocked_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_clockedschedule`
--

LOCK TABLES `django_celery_beat_clockedschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_crontabschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_crontabschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_crontabschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `minute` varchar(240) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hour` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_week` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_month` varchar(124) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month_of_year` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_crontabschedule`
--

LOCK TABLES `django_celery_beat_crontabschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_intervalschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_intervalschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_intervalschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `every` int NOT NULL,
  `period` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_intervalschedule`
--

LOCK TABLES `django_celery_beat_intervalschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictask`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `args` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `kwargs` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exchange` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `routing_key` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires` datetime(6) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_run_at` datetime(6) DEFAULT NULL,
  `total_run_count` int unsigned NOT NULL,
  `date_changed` datetime(6) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `crontab_id` int DEFAULT NULL,
  `interval_id` int DEFAULT NULL,
  `solar_id` int DEFAULT NULL,
  `one_off` tinyint(1) NOT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `priority` int unsigned DEFAULT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (_utf8mb3'{}'),
  `clocked_id` int DEFAULT NULL,
  `expire_seconds` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` (`crontab_id`),
  KEY `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` (`interval_id`),
  KEY `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` (`solar_id`),
  KEY `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` (`clocked_id`),
  CONSTRAINT `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` FOREIGN KEY (`clocked_id`) REFERENCES `django_celery_beat_clockedschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` FOREIGN KEY (`crontab_id`) REFERENCES `django_celery_beat_crontabschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` FOREIGN KEY (`interval_id`) REFERENCES `django_celery_beat_intervalschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` FOREIGN KEY (`solar_id`) REFERENCES `django_celery_beat_solarschedule` (`id`),
  CONSTRAINT `django_celery_beat_periodictask_chk_1` CHECK ((`total_run_count` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_2` CHECK ((`priority` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_3` CHECK ((`expire_seconds` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictask`
--

LOCK TABLES `django_celery_beat_periodictask` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictasks`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictasks` (
  `ident` smallint NOT NULL,
  `last_update` datetime(6) NOT NULL,
  PRIMARY KEY (`ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictasks`
--

LOCK TABLES `django_celery_beat_periodictasks` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_solarschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_solarschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_solarschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq` (`event`,`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_solarschedule`
--

LOCK TABLES `django_celery_beat_solarschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_chordcounter`
--

DROP TABLE IF EXISTS `django_celery_results_chordcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_chordcounter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_tasks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`),
  CONSTRAINT `django_celery_results_chordcounter_chk_1` CHECK ((`count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_chordcounter`
--

LOCK TABLES `django_celery_results_chordcounter` WRITE;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_groupresult`
--

DROP TABLE IF EXISTS `django_celery_results_groupresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_groupresult` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_done` datetime(6) NOT NULL,
  `content_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_encoding` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`),
  KEY `django_cele_date_cr_bd6c1d_idx` (`date_created`),
  KEY `django_cele_date_do_caae0e_idx` (`date_done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_groupresult`
--

LOCK TABLES `django_celery_results_groupresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_groupresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_groupresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_taskresult`
--

DROP TABLE IF EXISTS `django_celery_results_taskresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_taskresult` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_encoding` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` longtext COLLATE utf8mb4_unicode_ci,
  `date_done` datetime(6) NOT NULL,
  `traceback` longtext COLLATE utf8mb4_unicode_ci,
  `meta` longtext COLLATE utf8mb4_unicode_ci,
  `task_args` longtext COLLATE utf8mb4_unicode_ci,
  `task_kwargs` longtext COLLATE utf8mb4_unicode_ci,
  `task_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `worker` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime(6) NOT NULL,
  `periodic_task_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `django_cele_task_na_08aec9_idx` (`task_name`),
  KEY `django_cele_status_9b6201_idx` (`status`),
  KEY `django_cele_worker_d54dd8_idx` (`worker`),
  KEY `django_cele_date_cr_f04a50_idx` (`date_created`),
  KEY `django_cele_date_do_f59aad_idx` (`date_done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_taskresult`
--

LOCK TABLES `django_celery_results_taskresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_taskresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_taskresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(6,'authtoken','token'),(7,'authtoken','tokenproxy'),(51,'common','auditlog'),(52,'common','fileupload'),(53,'common','notification'),(54,'common','systembackup'),(55,'common','systemconfig'),(4,'contenttypes','contenttype'),(15,'django_celery_beat','clockedschedule'),(10,'django_celery_beat','crontabschedule'),(11,'django_celery_beat','intervalschedule'),(12,'django_celery_beat','periodictask'),(13,'django_celery_beat','periodictasks'),(14,'django_celery_beat','solarschedule'),(17,'django_celery_results','chordcounter'),(18,'django_celery_results','groupresult'),(16,'django_celery_results','taskresult'),(38,'equipment','equipment'),(39,'equipment','equipmentmaintenance'),(40,'equipment','equipmentusagerecord'),(8,'guardian','groupobjectpermission'),(9,'guardian','userobjectpermission'),(47,'reports','generatedreport'),(48,'reports','reportaccess'),(49,'reports','reportschedule'),(50,'reports','reporttemplate'),(5,'sessions','session'),(27,'tasks','discspringtestdata'),(29,'tasks','generictestdata'),(21,'tasks','prioritytype'),(25,'tasks','subtask'),(26,'tasks','subtaskdata'),(22,'tasks','taskstatus'),(23,'tasks','testtask'),(57,'tasks','testtaskreport'),(24,'tasks','testtype'),(28,'tasks','testtypefield'),(30,'test_data','antisliptestdata'),(31,'test_data','compressiontestdata'),(32,'test_data','corrosiontestdata'),(33,'test_data','creeptestdata'),(34,'test_data','fatiguetestdata'),(35,'test_data','hardnesstestdata'),(36,'test_data','metalimpacttestdata'),(37,'test_data','metaltensiletestdata'),(41,'tooling','tooling'),(42,'tooling','toolingmaintenance'),(59,'tooling','toolingreservation'),(58,'tooling','toolingscrapapplication'),(43,'tooling','toolingusagerecord'),(44,'tools','tool'),(45,'tools','toolborrowrecord'),(46,'tools','toolcalibration'),(19,'users','department'),(56,'users','role'),(20,'users','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-11-27 02:45:47.798455'),(2,'contenttypes','0002_remove_content_type_name','2025-11-27 02:45:47.824813'),(3,'auth','0001_initial','2025-11-27 02:45:47.905199'),(4,'auth','0002_alter_permission_name_max_length','2025-11-27 02:45:48.018629'),(5,'auth','0003_alter_user_email_max_length','2025-11-27 02:45:48.030194'),(6,'auth','0004_alter_user_username_opts','2025-11-27 02:45:48.033566'),(7,'auth','0005_alter_user_last_login_null','2025-11-27 02:45:48.036902'),(8,'auth','0006_require_contenttypes_0002','2025-11-27 02:45:48.038973'),(9,'auth','0007_alter_validators_add_error_messages','2025-11-27 02:45:48.042259'),(10,'auth','0008_alter_user_username_max_length','2025-11-27 02:45:48.045434'),(11,'auth','0009_alter_user_last_name_max_length','2025-11-27 02:45:48.048923'),(12,'auth','0010_alter_group_name_max_length','2025-11-27 02:45:48.056812'),(13,'auth','0011_update_proxy_permissions','2025-11-27 02:45:48.061065'),(14,'auth','0012_alter_user_first_name_max_length','2025-11-27 02:45:48.064650'),(15,'users','0001_initial','2025-11-27 02:45:48.288673'),(16,'admin','0001_initial','2025-11-27 02:45:48.347811'),(17,'admin','0002_logentry_remove_auto_add','2025-11-27 02:45:48.355616'),(18,'admin','0003_logentry_add_action_flag_choices','2025-11-27 02:45:48.360000'),(19,'authtoken','0001_initial','2025-11-27 02:45:48.386986'),(20,'authtoken','0002_auto_20160226_1747','2025-11-27 02:45:48.400198'),(21,'authtoken','0003_tokenproxy','2025-11-27 02:45:48.402391'),(22,'common','0001_initial','2025-11-27 02:45:48.440042'),(23,'common','0002_initial','2025-11-27 02:45:48.588142'),(24,'django_celery_beat','0001_initial','2025-11-27 02:45:48.793250'),(25,'django_celery_beat','0002_auto_20161118_0346','2025-11-27 02:45:48.826363'),(26,'django_celery_beat','0003_auto_20161209_0049','2025-11-27 02:45:48.840725'),(27,'django_celery_beat','0004_auto_20170221_0000','2025-11-27 02:45:48.844253'),(28,'django_celery_beat','0005_add_solarschedule_events_choices','2025-11-27 02:45:48.847648'),(29,'django_celery_beat','0006_auto_20180322_0932','2025-11-27 02:45:48.889351'),(30,'django_celery_beat','0007_auto_20180521_0826','2025-11-27 02:45:48.990282'),(31,'django_celery_beat','0008_auto_20180914_1922','2025-11-27 02:45:49.005995'),(32,'django_celery_beat','0006_auto_20180210_1226','2025-11-27 02:45:49.015261'),(33,'django_celery_beat','0006_periodictask_priority','2025-11-27 02:45:49.043568'),(34,'django_celery_beat','0009_periodictask_headers','2025-11-27 02:45:49.072291'),(35,'django_celery_beat','0010_auto_20190429_0326','2025-11-27 02:45:49.153116'),(36,'django_celery_beat','0011_auto_20190508_0153','2025-11-27 02:45:49.189365'),(37,'django_celery_beat','0012_periodictask_expire_seconds','2025-11-27 02:45:49.219250'),(38,'django_celery_beat','0013_auto_20200609_0727','2025-11-27 02:45:49.226264'),(39,'django_celery_beat','0014_remove_clockedschedule_enabled','2025-11-27 02:45:49.240452'),(40,'django_celery_beat','0015_edit_solarschedule_events_choices','2025-11-27 02:45:49.243239'),(41,'django_celery_beat','0016_alter_crontabschedule_timezone','2025-11-27 02:45:49.249152'),(42,'django_celery_beat','0017_alter_crontabschedule_month_of_year','2025-11-27 02:45:49.253375'),(43,'django_celery_beat','0018_improve_crontab_helptext','2025-11-27 02:45:49.257610'),(44,'django_celery_results','0001_initial','2025-11-27 02:45:49.272426'),(45,'django_celery_results','0002_add_task_name_args_kwargs','2025-11-27 02:45:49.315636'),(46,'django_celery_results','0003_auto_20181106_1101','2025-11-27 02:45:49.318697'),(47,'django_celery_results','0004_auto_20190516_0412','2025-11-27 02:45:49.347737'),(48,'django_celery_results','0005_taskresult_worker','2025-11-27 02:45:49.373345'),(49,'django_celery_results','0006_taskresult_date_created','2025-11-27 02:45:49.410270'),(50,'django_celery_results','0007_remove_taskresult_hidden','2025-11-27 02:45:49.430346'),(51,'django_celery_results','0008_chordcounter','2025-11-27 02:45:49.439867'),(52,'django_celery_results','0009_groupresult','2025-11-27 02:45:49.542170'),(53,'django_celery_results','0010_remove_duplicate_indices','2025-11-27 02:45:49.548550'),(54,'django_celery_results','0011_taskresult_periodic_task_name','2025-11-27 02:45:49.566489'),(55,'tasks','0001_initial','2025-11-27 02:45:49.597334'),(56,'equipment','0001_initial','2025-11-27 02:45:49.636956'),(57,'equipment','0002_initial','2025-11-27 02:45:49.656396'),(58,'equipment','0003_initial','2025-11-27 02:45:49.769377'),(59,'guardian','0001_initial','2025-11-27 02:45:49.932924'),(60,'guardian','0002_generic_permissions_index','2025-11-27 02:45:49.958096'),(61,'reports','0001_initial','2025-11-27 02:45:49.986743'),(62,'reports','0002_initial','2025-11-27 02:45:50.198147'),(63,'sessions','0001_initial','2025-11-27 02:45:50.211625'),(64,'tasks','0002_initial','2025-11-27 02:45:50.395174'),(65,'tasks','0003_testtask_requester_department_and_more','2025-11-27 02:45:50.516248'),(66,'tasks','0004_testtask_rejection_reason','2025-11-27 02:45:50.558949'),(67,'tasks','0005_subtask_subtaskdata','2025-11-27 02:45:50.701523'),(68,'tasks','0006_disc_spring_test_data_with_test_number','2025-11-27 02:45:50.744037'),(69,'tasks','0007_testtypefield','2025-11-27 02:45:50.798982'),(70,'tasks','0008_generictestdata','2025-11-27 02:45:50.851032'),(71,'tasks','0009_add_disc_spring_field_config','2025-11-27 02:45:50.879156'),(72,'test_data','0001_initial','2025-11-27 02:45:50.983653'),(73,'test_data','0002_initial','2025-11-27 02:45:51.556320'),(74,'tooling','0001_initial','2025-11-27 02:45:51.638843'),(75,'tooling','0002_initial','2025-11-27 02:45:51.847846'),(76,'tools','0001_initial','2025-11-27 02:45:51.875105'),(77,'tools','0002_initial','2025-11-27 02:45:52.145859'),(78,'users','0002_initial_departments','2025-11-27 02:45:52.173377'),(79,'users','0003_initial_admin_user','2025-11-27 02:45:52.311326'),(80,'users','0004_user_remark_user_role_user_status_alter_user_email','2025-11-27 02:45:52.626208'),(81,'users','0005_remove_user_is_active_remove_user_remark_and_more','2025-11-27 02:45:52.901343'),(82,'users','0006_alter_user_phone','2025-11-27 02:45:52.917283'),(83,'users','0007_remove_user_first_name_last_name','2025-11-27 02:45:53.034169'),(84,'users','0008_user_first_name_user_last_name','2025-11-27 02:45:53.195333'),(85,'users','0009_alter_user_department_delete_department','2025-11-27 02:45:53.214764'),(86,'users','0010_department','2026-01-07 07:11:53.307228'),(87,'users','0011_auto_20251110_1857','2026-01-07 07:12:02.115220'),(88,'users','0012_alter_user_role','2026-01-07 07:12:02.144474'),(89,'users','0013_role','2026-01-07 07:12:02.307190'),(90,'tasks','0010_testtype_level_type_testtype_parent','2026-01-08 03:28:45.426594'),(91,'tasks','0011_testtask_product_model_testtask_product_name','2026-01-08 03:28:45.865280'),(92,'tasks','0012_alter_testtask_product_model_and_more','2026-01-08 03:28:45.919935'),(93,'tasks','0013_alter_testtask_description','2026-01-08 03:28:45.949277'),(94,'tasks','0014_testtaskreport','2026-01-08 03:28:46.135631'),(95,'tooling','0003_tooling_attachment_tooling_image_and_more','2026-01-08 03:28:46.645370'),(96,'tools','0003_alter_tool_purchase_date_alter_tool_purchase_price','2026-01-08 03:28:46.774404');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('20k3yf545bnexpzedqdch8vzj6cq3chy','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vVR0R:YY55kWbqBBBth9bbMLLVbt4ljTNhrZiG2Au0K-XsgQ0','2025-12-17 09:06:07.822492'),('2l9d33j3o4pyu2z1qkatzbp34ok0cb89','.eJxVjMsOwiAQRf-FtSE8B3Dp3m8gAwNSNTQp7cr479qkC93ec859sYjb2uI2yhInYmcmgZ1-x4T5UfpO6I79NvM893WZEt8VftDBrzOV5-Vw_w4ajvata0LIAby32iGRLpC0chlkNoTCOKmqTUYIp0AHLZJAZWsBKUDl4Emz9wcE5jdq:1vVmFx:KGvMqORoSUVRF4S7DHRsobp3Dat8xNVEFRtjEDDLrwg','2025-12-18 07:47:33.277107'),('5i3usnedghorgu1z45r6djcvuvastzal','.eJxVjEEOwiAQRe_C2pCCwIBL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERSpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7emcx58SHlwhj061AxkwJMLFtF5NTlCQAWkwDub7aSTCRYSBWs4aS_eH-ooN-s:1vVNB6:JyTSqQhBCNZ9jRvcs1BPOB5-Npb6qdgAJNJzZBQld3Q','2025-12-17 05:00:52.476554'),('8zwhd5cu49ns1fknj5hnv01v27tp1jko','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vdNwg:G4UXnoXs2RQNbcpA_2e2aaUrh5cSyhqm1Si5-uaKQbQ','2026-01-08 07:27:06.911112'),('9c9nj434yfod9fmjx91gkjwhb306autx','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vgC87:-VhKaf13dVQkM_MvP_PCmBUp24wN9r1Ud2GCYYz5LgE','2026-01-16 01:26:31.821478'),('9s1mx1azqo0y4ds659heqvmd042ytdwh','.eJxVjDsOwjAQBe_iGllZ_01JzxmstXdNAiiW4qRC3B0ipYD2zcx7iYTbOqat85ImEmcRxOl3y1gePO-A7jjfmixtXpcpy12RB-3y2oifl8P9Oxixj9_aKk-EkSlWkx14l300hqJyGiwAqKgqlsJcSVfUzIFNyAMXG1UZAMT7A-7lOD4:1vWqp0:nPCkDFOV6Vcp4EltOKRvdi6LJ3zMhTbxxBNHLcalhcQ','2025-12-21 06:52:10.829550'),('ewp1p7kn0574dnllfqqqfd8wmaeuqhc2','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1va3I9:B_YPrIeMZXHPYfJALQmW6IxjtG5zyL4_88DZYe83sEA','2025-12-30 02:47:29.239459'),('ndvarhpa1j77mpkpk7gp25f3l5zwcoip','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vVhhX:pvjCeS0GkT3tWZHBSFiisARSFMiJY8KoNb5kGsAdbw0','2025-12-18 02:55:43.297233'),('p6ockelrqxoz2s5xoje0v4icvdkl7utq','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vVhwB:UJ3UHi7eHqwbJE5k6Uy9JLjvQgX9oIHz5nyFTARHYgo','2025-12-18 03:10:51.249559'),('pzsyvn91riidm4vchbak24dlqi117xu3','.eJxVjDsOwjAQBe_iGllZ_01JzxmstXdNAiiW4qRC3B0ipYD2zcx7iYTbOqat85ImEmcRxOl3y1gePO-A7jjfmixtXpcpy12RB-3y2oifl8P9Oxixj9_aKk-EkSlWkx14l300hqJyGiwAqKgqlsJcSVfUzIFNyAMXG1UZAMT7A-7lOD4:1vVmDM:zS1mQ9Iyfn2ayGu_i3bzUZ7zoMki8ga867kSq_FZRwo','2025-12-18 07:44:52.080359'),('qj9qfll1o15lzpgpzrmnxdcmspv0uc10','.eJxVjEEOwiAQRe_C2pCCwIBL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERSpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7emcx58SHlwhj061AxkwJMLFtF5NTlCQAWkwDub7aSTCRYSBWs4aS_eH-ooN-s:1vVLP4:g1nQKit0zPYTQpoS72WPQ67qkDSaRh4CWr5tJRhx8Eo','2025-12-17 03:07:10.932155'),('r2h3gcrxjn9jlmum0x83f74yvmsede7z','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vdN2k:HcVpmjc19qaKgfEH0hl-dpATZaUK48jhMYV3dVCb_UI','2026-01-08 06:29:18.967320'),('rb81mf7vj2bilb9fr2e87c8gu8oz19u9','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vVlbJ:JG2XlspBQKAHlLEp5Lzxk-tIJxUdq3Xncz94VpwjQMw','2025-12-18 07:05:33.208414'),('umq5s3u21ulzw7bqa36i3a2i44oeu42c','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vWTI7:FdWdQ2Coy6s9Tt-GqFRV4rokTwgovEshTJSi_kmVG_0','2025-12-20 05:44:39.978592'),('v05v9yfadxmp8xxrm4icobkajaqc5tod','.eJxVjMsOwiAQRf-FtSE8B3Dp3m8gAwNSNTQp7cr479qkC93ec859sYjb2uI2yhInYmcmgZ1-x4T5UfpO6I79NvM893WZEt8VftDBrzOV5-Vw_w4ajvata0LIAby32iGRLpC0chlkNoTCOKmqTUYIp0AHLZJAZWsBKUDl4Emz9wcE5jdq:1vVm5F:dP68pLsWC_iFshTP2gpUKm-SVW2DPdTyZbIhOHj-dNw','2025-12-18 07:36:29.011546'),('vsu4harokk6wag32s6slbnkjk6trs6vy','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1ve3HU:Gbt2Xot_XKCHwNS3yaV7MyusnWd7mR2ZPdkrMBS1zic','2026-01-10 03:35:20.557792'),('z5tku0rctybvw2i0jvmctut3220bf2b9','.eJxVjDsOwjAQBe_iGllk_aekzxmstXeNA8iR4qRC3B0ipYD2zcx7iYjbWuPWeYkTiYvQ4vS7JcwPbjugO7bbLPPc1mVKclfkQbscZ-Ln9XD_Dir2-q2zy2yUO3sLSRMXp7NFq4LL6IERlFWoC3vHppSEQ1AFgMJABpQnMOL9AfI9OBQ:1vWrtT:_KwhWsVaY2rLMnsRKg5ROD6RmzIT2bxS-GZpyr7ToI8','2025-12-21 08:00:51.567012');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `equipment_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_price` decimal(12,2) NOT NULL,
  `warranty_period` int NOT NULL,
  `warranty_end_date` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specifications` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `operating_manual` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_maintenance_date` date DEFAULT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `maintenance_interval` int NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `responsible_person_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_id` (`equipment_id`),
  UNIQUE KEY `serial_number` (`serial_number`),
  KEY `equipment_responsible_person_id_a39b48eb_fk_users_id` (`responsible_person_id`),
  CONSTRAINT `equipment_responsible_person_id_a39b48eb_fk_users_id` FOREIGN KEY (`responsible_person_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_maintenance`
--

DROP TABLE IF EXISTS `equipment_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_maintenance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `maintenance_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maintenance_date` date NOT NULL,
  `maintenance_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parts_replaced` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `maintenance_cost` decimal(10,2) NOT NULL,
  `maintenance_result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `equipment_id` bigint NOT NULL,
  `maintenance_person_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `equipment_maintenance_equipment_id_6e96e858_fk_equipment_id` (`equipment_id`),
  KEY `equipment_maintenance_maintenance_person_id_dd500fab_fk_users_id` (`maintenance_person_id`),
  CONSTRAINT `equipment_maintenance_equipment_id_6e96e858_fk_equipment_id` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `equipment_maintenance_maintenance_person_id_dd500fab_fk_users_id` FOREIGN KEY (`maintenance_person_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_maintenance`
--

LOCK TABLES `equipment_maintenance` WRITE;
/*!40000 ALTER TABLE `equipment_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_usage_records`
--

DROP TABLE IF EXISTS `equipment_usage_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_usage_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `usage_purpose` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usage_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `equipment_condition` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `equipment_id` bigint NOT NULL,
  `test_task_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `equipment_usage_records_equipment_id_50028011_fk_equipment_id` (`equipment_id`),
  KEY `equipment_usage_records_test_task_id_84b96953_fk_test_tasks_id` (`test_task_id`),
  KEY `equipment_usage_records_user_id_e266cfce_fk_users_id` (`user_id`),
  CONSTRAINT `equipment_usage_records_equipment_id_50028011_fk_equipment_id` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `equipment_usage_records_test_task_id_84b96953_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `equipment_usage_records_user_id_e266cfce_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_usage_records`
--

LOCK TABLES `equipment_usage_records` WRITE;
/*!40000 ALTER TABLE `equipment_usage_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_usage_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fatigue_test_data`
--

DROP TABLE IF EXISTS `fatigue_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fatigue_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `frequency` decimal(6,2) NOT NULL,
  `stress_ratio` decimal(4,2) NOT NULL,
  `max_stress` decimal(8,2) NOT NULL,
  `min_stress` decimal(8,2) NOT NULL,
  `cycles_to_failure` bigint NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fatigue_test_data_test_task_id_cf92560f_fk_test_tasks_id` (`test_task_id`),
  KEY `fatigue_test_data_tester_id_84df605f_fk_users_id` (`tester_id`),
  CONSTRAINT `fatigue_test_data_test_task_id_cf92560f_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `fatigue_test_data_tester_id_84df605f_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fatigue_test_data`
--

LOCK TABLES `fatigue_test_data` WRITE;
/*!40000 ALTER TABLE `fatigue_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `fatigue_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploads`
--

DROP TABLE IF EXISTS `file_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_uploads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_object_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_object_id` int unsigned DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `download_count` int NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `uploaded_by_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_uploads_uploaded_by_id_e06d8b37_fk_users_id` (`uploaded_by_id`),
  CONSTRAINT `file_uploads_uploaded_by_id_e06d8b37_fk_users_id` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `file_uploads_chk_1` CHECK ((`related_object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploads`
--

LOCK TABLES `file_uploads` WRITE;
/*!40000 ALTER TABLE `file_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generated_reports`
--

DROP TABLE IF EXISTS `generated_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `generated_reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `report_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `generation_params` json NOT NULL,
  `date_range_start` date NOT NULL,
  `date_range_end` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `output_format` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint NOT NULL,
  `generation_time` bigint DEFAULT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `download_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `generated_by_id` bigint NOT NULL,
  `template_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generated_reports_generated_by_id_9393ec13_fk_users_id` (`generated_by_id`),
  KEY `generated_reports_template_id_f3905847_fk_report_templates_id` (`template_id`),
  CONSTRAINT `generated_reports_generated_by_id_9393ec13_fk_users_id` FOREIGN KEY (`generated_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `generated_reports_template_id_f3905847_fk_report_templates_id` FOREIGN KEY (`template_id`) REFERENCES `report_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generated_reports`
--

LOCK TABLES `generated_reports` WRITE;
/*!40000 ALTER TABLE `generated_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `generated_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_test_data`
--

DROP TABLE IF EXISTS `generic_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `generic_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `test_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_data` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `subtask_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `test_number` (`test_number`),
  KEY `generic_tes_subtask_4eec08_idx` (`subtask_id`,`created_at` DESC),
  CONSTRAINT `generic_test_data_subtask_id_91f2759b_fk_sub_tasks_id` FOREIGN KEY (`subtask_id`) REFERENCES `sub_tasks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_test_data`
--

LOCK TABLES `generic_test_data` WRITE;
/*!40000 ALTER TABLE `generic_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guardian_groupobjectpermission`
--

DROP TABLE IF EXISTS `guardian_groupobjectpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_groupobjectpermission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `object_pk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guardian_groupobjectperm_group_id_permission_id_o_3f189f7c_uniq` (`group_id`,`permission_id`,`object_pk`),
  KEY `guardian_groupobject_permission_id_36572738_fk_auth_perm` (`permission_id`),
  KEY `guardian_gr_content_ae6aec_idx` (`content_type_id`,`object_pk`),
  CONSTRAINT `guardian_groupobject_content_type_id_7ade36b8_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `guardian_groupobject_group_id_4bbbfb62_fk_auth_grou` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `guardian_groupobject_permission_id_36572738_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardian_groupobjectpermission`
--

LOCK TABLES `guardian_groupobjectpermission` WRITE;
/*!40000 ALTER TABLE `guardian_groupobjectpermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `guardian_groupobjectpermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guardian_userobjectpermission`
--

DROP TABLE IF EXISTS `guardian_userobjectpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_userobjectpermission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `object_pk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guardian_userobjectpermi_user_id_permission_id_ob_b0b3d2fc_uniq` (`user_id`,`permission_id`,`object_pk`),
  KEY `guardian_userobjectp_permission_id_71807bfc_fk_auth_perm` (`permission_id`),
  KEY `guardian_us_content_179ed2_idx` (`content_type_id`,`object_pk`),
  CONSTRAINT `guardian_userobjectp_content_type_id_2e892405_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `guardian_userobjectp_permission_id_71807bfc_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `guardian_userobjectpermission_user_id_d5c1e964_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardian_userobjectpermission`
--

LOCK TABLES `guardian_userobjectpermission` WRITE;
/*!40000 ALTER TABLE `guardian_userobjectpermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `guardian_userobjectpermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardness_test_data`
--

DROP TABLE IF EXISTS `hardness_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hardness_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `test_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `load_force` decimal(8,2) NOT NULL,
  `hardness_value` decimal(8,2) NOT NULL,
  `indentation_depth` decimal(6,3) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hardness_test_data_test_task_id_d2d05a08_fk_test_tasks_id` (`test_task_id`),
  KEY `hardness_test_data_tester_id_8918a271_fk_users_id` (`tester_id`),
  CONSTRAINT `hardness_test_data_test_task_id_d2d05a08_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `hardness_test_data_tester_id_8918a271_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardness_test_data`
--

LOCK TABLES `hardness_test_data` WRITE;
/*!40000 ALTER TABLE `hardness_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `hardness_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metal_impact_test_data`
--

DROP TABLE IF EXISTS `metal_impact_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metal_impact_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `impact_energy` decimal(8,2) NOT NULL,
  `impact_strength` decimal(8,2) NOT NULL,
  `fracture_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `metal_impact_test_data_test_task_id_699afdce_fk_test_tasks_id` (`test_task_id`),
  KEY `metal_impact_test_data_tester_id_0d347bc3_fk_users_id` (`tester_id`),
  CONSTRAINT `metal_impact_test_data_test_task_id_699afdce_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `metal_impact_test_data_tester_id_0d347bc3_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metal_impact_test_data`
--

LOCK TABLES `metal_impact_test_data` WRITE;
/*!40000 ALTER TABLE `metal_impact_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `metal_impact_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metal_tensile_test_data`
--

DROP TABLE IF EXISTS `metal_tensile_test_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metal_tensile_test_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sample_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `strain_rate` decimal(8,6) NOT NULL,
  `tensile_strength` decimal(8,2) NOT NULL,
  `yield_strength` decimal(8,2) NOT NULL,
  `elongation` decimal(6,2) NOT NULL,
  `elastic_modulus` decimal(10,2) NOT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint NOT NULL,
  `tester_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `metal_tensile_test_data_test_task_id_d77a44a9_fk_test_tasks_id` (`test_task_id`),
  KEY `metal_tensile_test_data_tester_id_e3939d67_fk_users_id` (`tester_id`),
  CONSTRAINT `metal_tensile_test_data_test_task_id_d77a44a9_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `metal_tensile_test_data_tester_id_e3939d67_fk_users_id` FOREIGN KEY (`tester_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metal_tensile_test_data`
--

LOCK TABLES `metal_tensile_test_data` WRITE;
/*!40000 ALTER TABLE `metal_tensile_test_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `metal_tensile_test_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL,
  `read_at` datetime(6) DEFAULT NULL,
  `related_object_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_object_id` int unsigned DEFAULT NULL,
  `send_email` tinyint(1) NOT NULL,
  `email_sent` tinyint(1) NOT NULL,
  `email_sent_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `recipient_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_recipient_id_e1133bac_fk_users_id` (`recipient_id`),
  CONSTRAINT `notifications_recipient_id_e1133bac_fk_users_id` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`),
  CONSTRAINT `notifications_chk_1` CHECK ((`related_object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_types`
--

DROP TABLE IF EXISTS `priority_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_types` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_types`
--

LOCK TABLES `priority_types` WRITE;
/*!40000 ALTER TABLE `priority_types` DISABLE KEYS */;
INSERT INTO `priority_types` VALUES (1,'低',1,'低优先级任务，对时间要求不高','2026-01-08 13:12:07.000000','2026-01-08 13:12:07.000000'),(2,'中',2,'普通优先级任务，按正常进度执行','2026-01-08 13:12:07.000000','2026-01-08 13:12:07.000000'),(3,'高',3,'高优先级任务，需要优先安排资源','2026-01-08 13:12:07.000000','2026-01-08 13:12:07.000000'),(4,'紧急',4,'最高优先级任务，需立即响应并处理','2026-01-08 13:12:07.000000','2026-01-08 13:12:07.000000');
/*!40000 ALTER TABLE `priority_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_access`
--

DROP TABLE IF EXISTS `report_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_access` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` char(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `report_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_access_report_id_17b97feb_fk_generated_reports_id` (`report_id`),
  KEY `report_access_user_id_0b26091d_fk_users_id` (`user_id`),
  CONSTRAINT `report_access_report_id_17b97feb_fk_generated_reports_id` FOREIGN KEY (`report_id`) REFERENCES `generated_reports` (`id`),
  CONSTRAINT `report_access_user_id_0b26091d_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_access`
--

LOCK TABLES `report_access` WRITE;
/*!40000 ALTER TABLE `report_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_schedules`
--

DROP TABLE IF EXISTS `report_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schedule_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schedule_time` time(6) NOT NULL,
  `schedule_config` json NOT NULL,
  `generation_params` json NOT NULL,
  `output_format` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_recipients` json NOT NULL,
  `notification_enabled` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_run_time` datetime(6) DEFAULT NULL,
  `next_run_time` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint NOT NULL,
  `template_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_schedules_created_by_id_6bd597fb_fk_users_id` (`created_by_id`),
  KEY `report_schedules_template_id_1c99e420_fk_report_templates_id` (`template_id`),
  CONSTRAINT `report_schedules_created_by_id_6bd597fb_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `report_schedules_template_id_1c99e420_fk_report_templates_id` FOREIGN KEY (`template_id`) REFERENCES `report_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_schedules`
--

LOCK TABLES `report_schedules` WRITE;
/*!40000 ALTER TABLE `report_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_templates`
--

DROP TABLE IF EXISTS `report_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_templates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_config` json NOT NULL,
  `sql_query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `output_formats` json NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_templates_created_by_id_a75b451c_fk_users_id` (`created_by_id`),
  CONSTRAINT `report_templates_created_by_id_a75b451c_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_templates`
--

LOCK TABLES `report_templates` WRITE;
/*!40000 ALTER TABLE `report_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` json NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_tasks`
--

DROP TABLE IF EXISTS `sub_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `subtask_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtask_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `assignee_id` bigint DEFAULT NULL,
  `parent_task_id` bigint NOT NULL,
  `status_id` bigint NOT NULL,
  `test_type_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subtask_number` (`subtask_number`),
  KEY `sub_tasks_assignee_id_49405409_fk_users_id` (`assignee_id`),
  KEY `sub_tasks_parent_task_id_1508706a_fk_test_tasks_id` (`parent_task_id`),
  KEY `sub_tasks_status_id_42d9aa83_fk_task_status_id` (`status_id`),
  KEY `sub_tasks_test_type_id_00f38ed9_fk_test_types_id` (`test_type_id`),
  CONSTRAINT `sub_tasks_assignee_id_49405409_fk_users_id` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`),
  CONSTRAINT `sub_tasks_parent_task_id_1508706a_fk_test_tasks_id` FOREIGN KEY (`parent_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `sub_tasks_status_id_42d9aa83_fk_task_status_id` FOREIGN KEY (`status_id`) REFERENCES `task_status` (`id`),
  CONSTRAINT `sub_tasks_test_type_id_00f38ed9_fk_test_types_id` FOREIGN KEY (`test_type_id`) REFERENCES `test_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_tasks`
--

LOCK TABLES `sub_tasks` WRITE;
/*!40000 ALTER TABLE `sub_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subtask_data`
--

DROP TABLE IF EXISTS `subtask_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subtask_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `test_conditions` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_method` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_equipment` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_data` json NOT NULL,
  `test_result` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_conclusion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_file` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `subtask_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subtask_id` (`subtask_id`),
  CONSTRAINT `subtask_data_subtask_id_82d44465_fk_sub_tasks_id` FOREIGN KEY (`subtask_id`) REFERENCES `sub_tasks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtask_data`
--

LOCK TABLES `subtask_data` WRITE;
/*!40000 ALTER TABLE `subtask_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `subtask_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_backups`
--

DROP TABLE IF EXISTS `system_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_backups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_config` json NOT NULL,
  `backup_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_count` int NOT NULL,
  `backup_size` bigint NOT NULL,
  `duration` bigint DEFAULT NULL,
  `started_at` datetime(6) NOT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `started_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_backups_started_by_id_c6fd2d42_fk_users_id` (`started_by_id`),
  CONSTRAINT `system_backups_started_by_id_c6fd2d42_fk_users_id` FOREIGN KEY (`started_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_backups`
--

LOCK TABLES `system_backups` WRITE;
/*!40000 ALTER TABLE `system_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_editable` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_status`
--

DROP TABLE IF EXISTS `task_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_status` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_status`
--

LOCK TABLES `task_status` WRITE;
/*!40000 ALTER TABLE `task_status` DISABLE KEYS */;
INSERT INTO `task_status` VALUES (1,'待分配','pending','任务已创建，等待分配','2025-11-12 10:06:40.000000','2025-11-12 10:06:40.000000'),(2,'进行中','in_progress','任务正在执行中','2025-11-12 10:06:40.000000','2025-11-12 10:06:40.000000'),(3,'已完成','completed','任务已完成','2025-11-12 10:06:40.000000','2025-11-12 10:06:40.000000'),(4,'已拒绝','rejected','任务被拒绝','2025-11-12 10:06:40.000000','2025-11-12 10:06:40.000000'),(5,'待审核','pending_review','任务已完成，等待试验室主管审核','2025-11-13 01:44:43.000000','2025-11-13 01:44:43.000000'),(6,'审核完成','reviewed','任务已通过审核，正式完成','2025-11-13 01:44:43.000000','2025-11-13 01:44:43.000000');
/*!40000 ALTER TABLE `task_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_task_reports`
--

DROP TABLE IF EXISTS `test_task_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_task_reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `task_id` bigint NOT NULL,
  `uploader_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `test_task_reports_task_id_b65bf10e_fk_test_tasks_id` (`task_id`),
  KEY `test_task_reports_uploader_id_027aa72a_fk_users_id` (`uploader_id`),
  CONSTRAINT `test_task_reports_task_id_b65bf10e_fk_test_tasks_id` FOREIGN KEY (`task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `test_task_reports_uploader_id_027aa72a_fk_users_id` FOREIGN KEY (`uploader_id`) REFERENCES `users` (`id`),
  CONSTRAINT `test_task_reports_chk_1` CHECK ((`size` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_task_reports`
--

LOCK TABLES `test_task_reports` WRITE;
/*!40000 ALTER TABLE `test_task_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_task_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_tasks`
--

DROP TABLE IF EXISTS `test_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_outline` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_report` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_outline_file` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_report_file` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `assignee_id` bigint DEFAULT NULL,
  `priority_id` bigint NOT NULL,
  `requester_id` bigint NOT NULL,
  `status_id` bigint NOT NULL,
  `test_type_id` bigint NOT NULL,
  `requester_department` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requester_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requester_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rejection_reason` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (_utf8mb3''),
  `product_model` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_number` (`task_number`),
  KEY `test_tasks_assignee_id_aa53b163_fk_users_id` (`assignee_id`),
  KEY `test_tasks_priority_id_5e3607a5_fk_priority_types_id` (`priority_id`),
  KEY `test_tasks_requester_id_0b48ad67_fk_users_id` (`requester_id`),
  KEY `test_tasks_status_id_4fc1e2b8_fk_task_status_id` (`status_id`),
  KEY `test_tasks_test_type_id_a51770fb_fk_test_types_id` (`test_type_id`),
  CONSTRAINT `test_tasks_assignee_id_aa53b163_fk_users_id` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`),
  CONSTRAINT `test_tasks_priority_id_5e3607a5_fk_priority_types_id` FOREIGN KEY (`priority_id`) REFERENCES `priority_types` (`id`),
  CONSTRAINT `test_tasks_requester_id_0b48ad67_fk_users_id` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`),
  CONSTRAINT `test_tasks_status_id_4fc1e2b8_fk_task_status_id` FOREIGN KEY (`status_id`) REFERENCES `task_status` (`id`),
  CONSTRAINT `test_tasks_test_type_id_a51770fb_fk_test_types_id` FOREIGN KEY (`test_type_id`) REFERENCES `test_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_tasks`
--

LOCK TABLES `test_tasks` WRITE;
/*!40000 ALTER TABLE `test_tasks` DISABLE KEYS */;
INSERT INTO `test_tasks` VALUES (1,'TASK20260108001','碟簧测试','','','','','','2026-01-08','2026-01-15',NULL,NULL,'2026-01-08 09:38:22.471710','2026-01-08 09:38:22.471733',NULL,1,4,1,3,'试验室','杨明哲','18300613166','','','');
/*!40000 ALTER TABLE `test_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_type_fields`
--

DROP TABLE IF EXISTS `test_type_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_type_fields` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_options` json NOT NULL,
  `is_required` tinyint(1) NOT NULL,
  `default_value` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `placeholder` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `help_text` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_type_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `test_type_fields_test_type_id_field_code_f4f8cd46_uniq` (`test_type_id`,`field_code`),
  CONSTRAINT `test_type_fields_test_type_id_5c88b554_fk_test_types_id` FOREIGN KEY (`test_type_id`) REFERENCES `test_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_type_fields`
--

LOCK TABLES `test_type_fields` WRITE;
/*!40000 ALTER TABLE `test_type_fields` DISABLE KEYS */;
INSERT INTO `test_type_fields` VALUES (1,'试验照片','dhsy_zp','file','{\"images\": []}',0,'','','',10,1,'2026-01-08 07:55:22.976486','2026-01-08 07:55:22.976517',3),(2,'批次号','dh_pch','text','{}',0,'','','',0,1,'2026-01-08 07:56:14.004057','2026-01-08 07:57:36.696552',3),(3,'本批次总数','batch_total','number','{}',0,'','','',0,1,'2026-01-08 07:57:10.743234','2026-01-08 07:57:10.743253',3),(4,'供应商','dh_supplier','text','{}',0,'','','',4,1,'2026-01-08 07:59:15.215566','2026-01-08 07:59:15.215588',3),(5,'试验数量','dh_test_quantity','number','{}',0,'','','',5,1,'2026-01-08 08:00:14.571546','2026-01-08 08:00:14.571564',3),(6,'碟簧型号','dh_disc_spring_model','text','{}',0,'','','',0,1,'2026-01-08 08:00:49.537298','2026-01-08 08:00:49.537337',3),(7,'申请日期','application_date','text','{}',0,'','','',6,1,'2026-01-08 08:01:20.192116','2026-01-08 08:01:20.192157',3),(8,'2mm位移检验力值(kN)','displacement_2mm','decimal','{}',0,'','','',7,1,'2026-01-08 08:02:05.564821','2026-01-08 08:02:05.564867',3),(9,'2.5mm位移检验力值(kN)','displacement_2_5mm','decimal','{}',0,'','','',8,1,'2026-01-08 08:02:53.197940','2026-01-08 08:02:53.198001',3),(10,'试验员','inspector_name','text','{}',0,'','','',9,1,'2026-01-08 08:03:19.640954','2026-01-08 08:03:19.641026',3),(11,'检验时间','inspection_time','datetime','{}',0,'','','',11,1,'2026-01-08 08:03:58.364637','2026-01-08 08:03:58.364677',3),(12,'位移','lzq_zxwy','number','{}',0,'','','',0,1,'2026-01-09 00:04:57.958872','2026-01-09 00:04:57.958910',5),(13,'力值','lzq_zxlz','decimal','{}',0,'','','',1,1,'2026-01-09 00:06:01.673392','2026-01-09 00:06:15.271153',5),(14,'轴向刚度','lzq_zxgd','decimal','{}',0,'','','',3,1,'2026-01-09 00:07:01.197626','2026-01-09 00:07:01.197681',5),(15,'轴向刚度测试照片','lzq_cezp','file','{\"images\": []}',0,'','','',4,1,'2026-01-09 00:07:45.994024','2026-01-09 00:07:45.994069',5),(16,'备注','lzq_bz','text','{}',0,'','','',0,1,'2026-01-09 00:09:01.540252','2026-01-09 00:09:01.540295',5),(17,'径向位移','lzq_jxwy','number','{}',0,'','','',0,1,'2026-01-09 00:10:31.869560','2026-01-09 00:10:31.869615',6),(18,'径向力值','lzq_jxlz','decimal','{}',0,'','','',1,1,'2026-01-09 00:11:06.641492','2026-01-09 00:11:06.641516',6),(19,'联轴器径向刚度（N/mm）','lzq_jxgd','decimal','{}',0,'','','',2,1,'2026-01-09 00:12:01.534961','2026-01-09 00:12:01.535001',6),(20,'径向刚度测试照片','lzq_jxgdzp','file','{\"images\": []}',0,'','','',5,1,'2026-01-09 00:13:20.579737','2026-01-09 00:13:20.579756',6),(21,'备注','lzq_jxbz','text','{}',0,'','','',6,1,'2026-01-09 00:13:58.972929','2026-01-09 00:13:58.972948',6),(22,'联轴器疲劳载荷（kNm）','lzq_plzh','decimal','{}',0,'','','',0,1,'2026-01-09 02:27:47.306615','2026-01-09 02:27:47.306640',8),(23,'试验次数','lzq_sycs','number','{}',0,'','','',3,1,'2026-01-09 02:33:33.546593','2026-01-09 02:33:33.546626',8),(24,'整机疲劳照片','lzq_zjzp','file','{\"images\": []}',0,'','','',4,1,'2026-01-09 02:34:35.743353','2026-01-09 02:34:35.743379',8),(25,'轴向偏置','lzq_zxpz','decimal','{}',0,'','','',7,1,'2026-01-09 02:35:35.781874','2026-01-09 02:35:35.781899',8),(26,'径向偏置','lzq_jxpz','decimal','{}',0,'','','',8,1,'2026-01-09 02:36:04.855778','2026-01-09 02:36:04.855797',8),(27,'平衡半径（mm）','lzq_zjg_phbj','number','{}',0,'','','',0,1,'2026-01-09 02:46:35.762660','2026-01-09 02:46:35.762702',9),(28,'平衡转速(rpm)','lzq_zjg_phzs','number','{}',0,'','','',1,1,'2026-01-09 02:47:13.489280','2026-01-09 02:50:21.106682',9),(29,'理论不平衡量(g)','lzq_zjg_llbphl','decimal','{}',0,'','','',2,1,'2026-01-09 02:47:58.688213','2026-01-09 02:47:58.688278',9),(30,'剩余不平衡量左（g）','lzq_zjg_sybphlz','decimal','{}',0,'','','',3,1,'2026-01-09 02:49:02.197081','2026-01-09 02:49:32.800587',9),(31,'剩余不平衡量右（g）','lzq_zjg_sybphly','decimal','{}',0,'','','',5,1,'2026-01-09 02:49:58.602432','2026-01-09 02:50:08.948120',9),(32,'平衡半径（mm）','lzq_clxphbj','number','{}',0,'','','',0,1,'2026-01-09 03:34:14.636652','2026-01-09 03:34:14.636710',10),(33,'平衡转速(rpm)','lzq_clxphzs','decimal','{}',0,'','','',1,1,'2026-01-09 03:35:13.497614','2026-01-09 03:35:13.497634',10),(34,'摩擦片名称','mcp_name','text','{}',0,'','','',1,1,'2026-01-13 07:42:50.771084','2026-01-14 07:55:32.508433',12),(35,'摩擦片型号','mcp_tape','text','{}',0,'','','',2,1,'2026-01-13 07:43:15.406130','2026-01-14 07:55:36.086830',12),(36,'测试温度℃','mcp_cswd','decimal','{}',0,'','3','',4,1,'2026-01-13 07:44:54.899356','2026-01-14 07:55:50.040783',12),(37,'管路压力MPa','mcp_glyl','decimal','{}',0,'','','',5,1,'2026-01-13 07:47:57.572823','2026-01-14 07:55:54.169178',12),(38,'摩擦系数','mcp_mcxs','file','{\"images\": []}',0,'','','',6,1,'2026-01-13 07:48:31.954430','2026-01-14 07:56:39.284672',12),(39,'总行程','mcp_zxc','decimal','{}',0,'','','',7,1,'2026-01-13 07:49:07.683793','2026-01-14 07:56:02.650605',12),(40,'摩擦片批次号','mcp_pch','text','{}',0,'','','',0,1,'2026-01-14 05:07:13.826149','2026-01-14 05:07:13.826167',14),(41,'摩擦片供应商','mcp_gys','text','{}',0,'','','',0,1,'2026-01-14 05:07:52.174805','2026-01-14 05:08:43.709055',14),(42,'摩擦片材质','mcp_cz','text','{}',0,'','','',0,1,'2026-01-14 05:08:40.203658','2026-01-14 05:08:40.203676',14),(43,'冲击角度(°)','mcp_cjjd','decimal','{}',0,'','','',0,1,'2026-01-14 05:09:58.494314','2026-01-14 07:51:48.807871',14),(44,'冲击强度(KJ/m²)','mcp_cjqd','decimal','{}',0,'','','',0,1,'2026-01-14 05:11:19.675452','2026-01-14 05:11:19.675470',14),(45,'吸收能量(J)','mcp_xsnl','decimal','{}',0,'','','',0,1,'2026-01-14 07:51:25.373020','2026-01-14 07:51:38.711553',14),(46,'备注','mcp_cjbz','text','{}',0,'','','',0,1,'2026-01-14 07:52:56.381395','2026-01-14 07:53:11.943215',14),(47,'摩擦片测试比压','mcp_csby','decimal','{}',0,'','','',8,1,'2026-01-14 07:54:19.406416','2026-01-14 07:56:06.656998',12),(48,'摩擦片试验编号','mcp_sybh','text','{}',0,'','','',0,1,'2026-01-14 07:55:21.693027','2026-01-14 07:55:21.693070',12),(49,'摩擦片测试照片','mcp_cszp','file','{\"images\": []}',0,'','','',9,1,'2026-01-14 07:57:02.574842','2026-01-14 07:57:02.574883',12),(50,'测试开始时间','mcp_cskssj','date','{}',0,'','','',9,1,'2026-01-15 01:26:12.294629','2026-01-15 01:26:29.010539',12);
/*!40000 ALTER TABLE `test_type_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_types`
--

DROP TABLE IF EXISTS `test_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_types` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `level_type` int NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `test_types_parent_id_5f718185_fk_test_types_id` (`parent_id`),
  CONSTRAINT `test_types_parent_id_5f718185_fk_test_types_id` FOREIGN KEY (`parent_id`) REFERENCES `test_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_types`
--

LOCK TABLES `test_types` WRITE;
/*!40000 ALTER TABLE `test_types` DISABLE KEYS */;
INSERT INTO `test_types` VALUES (1,'摩擦垫片抗滑移测试','khy_test','摩擦垫片抗滑移测试','2025-12-16 06:34:45.087099','2025-12-16 06:34:45.087119',1,NULL),(2,'联轴器扭矩限制器测试','xzq_cs','联轴器扭矩限制器测试','2025-12-19 02:02:44.450769','2025-12-19 02:02:44.450793',1,NULL),(3,'碟簧试验','dh_text','碟簧测试','2026-01-08 07:01:42.991212','2026-01-08 07:01:42.991239',1,NULL),(4,'联轴器试验','LZQ_TEXT','该类型为联轴器整机的型式试验','2026-01-09 00:00:49.810956','2026-01-09 02:51:42.685174',1,NULL),(5,'联轴器轴向刚度测试','lzq_zx_text','联轴器轴向刚度测试','2026-01-09 00:04:16.141804','2026-01-09 01:02:58.552738',2,4),(6,'联轴器径向刚度测试','lzq_jxgd','联轴器的径向测试','2026-01-09 00:10:02.475983','2026-01-09 00:10:02.476018',2,4),(7,'联轴器扭转刚度测试','lzq_nzgd_text','联轴器扭转刚度测试','2026-01-09 00:16:52.001446','2026-01-09 01:02:50.391142',2,4),(8,'联轴器总成疲劳试验测试','lzq_zcpl_text','联轴器整机疲劳试验测试','2026-01-09 02:25:47.088392','2026-01-09 02:25:47.088412',2,4),(9,'中间管动平衡测试','lzq_zjgdph','中间管动平衡测试','2026-01-09 02:43:44.739755','2026-01-09 02:43:44.739795',2,4),(10,'齿轮箱侧动平衡','lzq_clxdph','刹车盘+涨紧套动平衡试验','2026-01-09 03:33:09.630754','2026-01-09 03:33:09.630796',2,4),(11,'摩擦片试验测试','MCP_TEXT','摩擦片试验测试包括摩擦系数、磨耗、拉伸、压缩、剪切冲击等试验内容','2026-01-13 07:40:35.407184','2026-01-13 07:40:35.407210',1,NULL),(12,'摩擦片摩擦系数测试','mcp_mcxs_test','摩擦片摩擦系数测试','2026-01-13 07:41:38.932153','2026-01-13 07:41:38.932174',2,11),(13,'摩擦片压缩试验','mcp_ys_text','摩擦片压缩试验','2026-01-14 04:59:53.507751','2026-01-14 04:59:53.507773',2,11),(14,'摩擦片冲击试验','mcp_cj_text','摩擦片冲击试验','2026-01-14 05:01:45.643085','2026-01-14 05:01:45.643124',2,11),(15,'摩擦片剪切试验','mcp_jq_text','摩擦片剪切试验','2026-01-14 05:03:50.495662','2026-01-14 05:03:50.495698',2,11),(16,'摩擦片拉伸试验','mcp_ls_text','摩擦片拉伸试验','2026-01-14 05:05:16.760002','2026-01-14 05:05:16.760022',2,11);
/*!40000 ALTER TABLE `test_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tool_borrow_records`
--

DROP TABLE IF EXISTS `tool_borrow_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tool_borrow_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `borrow_date` date NOT NULL,
  `expected_return_date` date NOT NULL,
  `actual_return_date` date DEFAULT NULL,
  `borrow_purpose` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_condition` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrow_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `approver_id` bigint DEFAULT NULL,
  `borrower_id` bigint NOT NULL,
  `test_task_id` bigint DEFAULT NULL,
  `tool_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tool_borrow_records_approver_id_68020a8e_fk_users_id` (`approver_id`),
  KEY `tool_borrow_records_borrower_id_56ee6820_fk_users_id` (`borrower_id`),
  KEY `tool_borrow_records_test_task_id_9f0db343_fk_test_tasks_id` (`test_task_id`),
  KEY `tool_borrow_records_tool_id_aa177727_fk_tools_id` (`tool_id`),
  CONSTRAINT `tool_borrow_records_approver_id_68020a8e_fk_users_id` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tool_borrow_records_borrower_id_56ee6820_fk_users_id` FOREIGN KEY (`borrower_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tool_borrow_records_test_task_id_9f0db343_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `tool_borrow_records_tool_id_aa177727_fk_tools_id` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tool_borrow_records`
--

LOCK TABLES `tool_borrow_records` WRITE;
/*!40000 ALTER TABLE `tool_borrow_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tool_borrow_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tool_calibration`
--

DROP TABLE IF EXISTS `tool_calibration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tool_calibration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `calibration_date` date NOT NULL,
  `calibration_agency` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calibration_standard` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calibration_method` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `environmental_conditions` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `calibration_result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `measurement_uncertainty` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calibration_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_file` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_until` date NOT NULL,
  `next_calibration_date` date NOT NULL,
  `calibration_cost` decimal(8,2) NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `calibration_person_id` bigint NOT NULL,
  `tool_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tool_calibration_calibration_person_id_e9b6c7c9_fk_users_id` (`calibration_person_id`),
  KEY `tool_calibration_tool_id_6cbe1ee5_fk_tools_id` (`tool_id`),
  CONSTRAINT `tool_calibration_calibration_person_id_e9b6c7c9_fk_users_id` FOREIGN KEY (`calibration_person_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tool_calibration_tool_id_6cbe1ee5_fk_tools_id` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tool_calibration`
--

LOCK TABLES `tool_calibration` WRITE;
/*!40000 ALTER TABLE `tool_calibration` DISABLE KEYS */;
/*!40000 ALTER TABLE `tool_calibration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tooling`
--

DROP TABLE IF EXISTS `tooling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tooling` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tooling_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specifications` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `material` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dimensions` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` decimal(8,2) DEFAULT NULL,
  `max_load` decimal(10,2) DEFAULT NULL,
  `operating_temperature_min` decimal(6,2) DEFAULT NULL,
  `operating_temperature_max` decimal(6,2) DEFAULT NULL,
  `last_maintenance_date` date DEFAULT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `maintenance_interval` int NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `responsible_person_id` bigint DEFAULT NULL,
  `attachment` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tooling_id` (`tooling_id`),
  KEY `tooling_responsible_person_id_0e5f7698_fk_users_id` (`responsible_person_id`),
  CONSTRAINT `tooling_responsible_person_id_0e5f7698_fk_users_id` FOREIGN KEY (`responsible_person_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tooling`
--

LOCK TABLES `tooling` WRITE;
/*!40000 ALTER TABLE `tooling` DISABLE KEYS */;
/*!40000 ALTER TABLE `tooling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tooling_maintenance`
--

DROP TABLE IF EXISTS `tooling_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tooling_maintenance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `maintenance_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maintenance_date` date NOT NULL,
  `maintenance_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parts_replaced` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `maintenance_cost` decimal(8,2) NOT NULL,
  `calibration_certificate` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calibration_due_date` date DEFAULT NULL,
  `maintenance_result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `maintenance_person_id` bigint NOT NULL,
  `tooling_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tooling_maintenance_maintenance_person_id_9708009b_fk_users_id` (`maintenance_person_id`),
  KEY `tooling_maintenance_tooling_id_8cd43b30_fk_tooling_id` (`tooling_id`),
  CONSTRAINT `tooling_maintenance_maintenance_person_id_9708009b_fk_users_id` FOREIGN KEY (`maintenance_person_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tooling_maintenance_tooling_id_8cd43b30_fk_tooling_id` FOREIGN KEY (`tooling_id`) REFERENCES `tooling` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tooling_maintenance`
--

LOCK TABLES `tooling_maintenance` WRITE;
/*!40000 ALTER TABLE `tooling_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tooling_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tooling_reservations`
--

DROP TABLE IF EXISTS `tooling_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tooling_reservations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) NOT NULL,
  `purpose` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approval_time` datetime(6) DEFAULT NULL,
  `rejection_reason` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `applicant_id` bigint NOT NULL,
  `approver_id` bigint DEFAULT NULL,
  `tooling_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tooling_reservations_applicant_id_cea59d9b_fk_users_id` (`applicant_id`),
  KEY `tooling_reservations_approver_id_b01349a6_fk_users_id` (`approver_id`),
  KEY `tooling_reservations_tooling_id_0eaa06af_fk_tooling_id` (`tooling_id`),
  CONSTRAINT `tooling_reservations_applicant_id_cea59d9b_fk_users_id` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tooling_reservations_approver_id_b01349a6_fk_users_id` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tooling_reservations_tooling_id_0eaa06af_fk_tooling_id` FOREIGN KEY (`tooling_id`) REFERENCES `tooling` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tooling_reservations`
--

LOCK TABLES `tooling_reservations` WRITE;
/*!40000 ALTER TABLE `tooling_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tooling_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tooling_scrap_applications`
--

DROP TABLE IF EXISTS `tooling_scrap_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tooling_scrap_applications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `apply_date` date NOT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approval_date` date DEFAULT NULL,
  `approval_note` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `applicant_id` bigint NOT NULL,
  `approver_id` bigint DEFAULT NULL,
  `tooling_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tooling_scrap_applications_applicant_id_49086fe7_fk_users_id` (`applicant_id`),
  KEY `tooling_scrap_applications_approver_id_9bfd4851_fk_users_id` (`approver_id`),
  KEY `tooling_scrap_applications_tooling_id_bb476af9_fk_tooling_id` (`tooling_id`),
  CONSTRAINT `tooling_scrap_applications_applicant_id_49086fe7_fk_users_id` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tooling_scrap_applications_approver_id_9bfd4851_fk_users_id` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tooling_scrap_applications_tooling_id_bb476af9_fk_tooling_id` FOREIGN KEY (`tooling_id`) REFERENCES `tooling` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tooling_scrap_applications`
--

LOCK TABLES `tooling_scrap_applications` WRITE;
/*!40000 ALTER TABLE `tooling_scrap_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tooling_scrap_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tooling_usage_records`
--

DROP TABLE IF EXISTS `tooling_usage_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tooling_usage_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `usage_purpose` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usage_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `load_applied` decimal(10,2) DEFAULT NULL,
  `temperature` decimal(6,2) DEFAULT NULL,
  `tooling_condition` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `test_task_id` bigint DEFAULT NULL,
  `tooling_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tooling_usage_records_test_task_id_b4612ae1_fk_test_tasks_id` (`test_task_id`),
  KEY `tooling_usage_records_tooling_id_4aaf7fa9_fk_tooling_id` (`tooling_id`),
  KEY `tooling_usage_records_user_id_6870abb5_fk_users_id` (`user_id`),
  CONSTRAINT `tooling_usage_records_test_task_id_b4612ae1_fk_test_tasks_id` FOREIGN KEY (`test_task_id`) REFERENCES `test_tasks` (`id`),
  CONSTRAINT `tooling_usage_records_tooling_id_4aaf7fa9_fk_tooling_id` FOREIGN KEY (`tooling_id`) REFERENCES `tooling` (`id`),
  CONSTRAINT `tooling_usage_records_user_id_6870abb5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tooling_usage_records`
--

LOCK TABLES `tooling_usage_records` WRITE;
/*!40000 ALTER TABLE `tooling_usage_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `tooling_usage_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tools`
--

DROP TABLE IF EXISTS `tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tools` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tool_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(8,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specifications` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `material` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dimensions` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` decimal(6,2) DEFAULT NULL,
  `accuracy` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `measurement_range` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_calibration_date` date DEFAULT NULL,
  `next_calibration_date` date DEFAULT NULL,
  `calibration_interval` int NOT NULL,
  `remarks` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `responsible_person_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tool_id` (`tool_id`),
  KEY `tools_responsible_person_id_8a1eefdf_fk_users_id` (`responsible_person_id`),
  CONSTRAINT `tools_responsible_person_id_8a1eefdf_fk_users_id` FOREIGN KEY (`responsible_person_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tools`
--

LOCK TABLES `tools` WRITE;
/*!40000 ALTER TABLE `tools` DISABLE KEYS */;
/*!40000 ALTER TABLE `tools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `employee_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `department_id` bigint DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_status` tinyint(1) NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `users_department_id_f0b302db_fk_departments_id` (`department_id`),
  CONSTRAINT `users_department_id_f0b302db_fk_departments_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'pbkdf2_sha256$600000$e1ItVKciFIsgUQLCNKKuFp$J5+qBbAMKIpOWTKqloj4XM3mK3swh/DgvvM6lcPHDzg=','2025-11-12 10:02:29.000000',1,'admin','admin@example.com',1,'2025-11-10 03:16:06.000000','1001','18300613166','','2025-11-27 02:45:52.307970','2025-11-12 03:57:14.000000',1,'admin',1,'',''),(4,'pbkdf2_sha256$600000$mFyzqC9h7aLYJpiXiBBafN$VF4QqYeTS1zF4Ib9RJIkf9mJf5FK+aT3K6KRa44mOms=','2026-01-13 07:39:20.600290',1,'杨明哲','504606628@qq.com',1,'2025-11-10 03:40:39.000000','JK00085','18300613166','','2025-11-10 03:40:39.000000','2025-12-03 02:25:07.000000',1,'manager',1,'',''),(5,'pbkdf2_sha256$600000$vEIIz36O63B8rxFherSpzx$D9F2UqFMkmlnQkpmlqRPJSW5hJu+MwroP81XddDyDWw=','2025-11-12 02:36:08.000000',0,'王战胜','',0,'2025-11-10 05:02:22.000000','JK00031','6333','','2025-11-10 05:02:22.000000','2025-11-10 09:35:40.000000',1,'engineer',1,'',''),(7,'pbkdf2_sha256$600000$Vh5PYdEwMe22dwFz9qUFCJ$+41ag33RNRdT1nXqyRvkqSVbXgNFn6N/n1ptEISIcL4=','2025-12-04 06:10:08.000000',0,'杨明源','',0,'2025-11-10 09:36:59.000000','JK00345','15978573971','','2025-11-10 09:37:00.000000','2025-11-10 09:37:00.000000',1,'engineer',1,'',''),(8,'pbkdf2_sha256$600000$2rf3gkvbAg4qQZB0XEIpHa$jW08+2ejqFV0/0aAkxhCHOp7YUBaIxIDX9QQiihdSMw=','2025-12-20 06:51:16.215682',0,'张帆','',0,'2025-11-10 09:37:58.000000','JK00197','15539180303/6961','','2025-11-10 09:37:58.000000','2025-11-10 09:37:58.000000',1,'engineer',1,'',''),(9,'pbkdf2_sha256$600000$kcIBobyC3I9XNW6o2yiTir$pvmkm9QfwCbc/IpnoLZvhFrHKqMsQSHMEYdU6vwHt8w=',NULL,0,'张朝昆','',0,'2025-11-10 09:39:38.000000','JK01301','未知','','2025-11-10 09:39:39.000000','2025-11-10 09:39:39.000000',1,'engineer',1,'',''),(10,'pbkdf2_sha256$600000$jCij1zrVH1sPL2mI15qWc7$80h+k/AcGfSUnuaFn2soIrQXANTTGCW6SApUs31S7Bg=',NULL,0,'段来玉','',0,'2025-11-10 09:40:50.000000','JK00930','未知','','2025-11-10 09:40:51.000000','2025-11-10 09:40:51.000000',1,'engineer',1,'',''),(11,'pbkdf2_sha256$600000$YVSTlaXzT0HWg3nZkqFGez$E/ExvVvs+CmcpmUTK/gQayckXSWWNCFmK/vPkwk9U9A=',NULL,0,'马保兴','',0,'2025-11-10 09:42:07.000000','JK00143','13569181978','','2025-11-10 09:42:08.000000','2025-11-10 09:42:08.000000',1,'engineer',1,'',''),(12,'pbkdf2_sha256$600000$h7Dwfk2ax2s22HSvUwjmi8$oUMHFu3QIYHp4UrzC9ZO/aRQwMB+rdcm+mO7G3X7B9o=','2025-11-12 09:59:09.000000',0,'宋金龙','',0,'2025-11-10 09:44:28.000000','JK00123','6742','','2025-11-10 09:44:28.000000','2025-11-10 09:44:37.000000',1,'engineer',1,'',''),(16,'pbkdf2_sha256$600000$udiUBkPGgcte7nx2Bxfc5F$/kq5s3NEwKy82qpYe/auM8ye+sIw7bA52KciVOs5Zh0=','2025-12-17 07:47:24.258858',0,'刘冬冬','',0,'2025-11-13 03:09:58.000000','JK00082','6558','研发二部部长','2025-11-13 03:09:58.000000','2025-11-13 03:09:58.000000',2,'guest',1,'',''),(19,'pbkdf2_sha256$600000$5vy8pr1Ggngr9rRuf3Uz1F$9h9u1pizwNO1hJLzrFpqQkqm93x7v1E0Ob6x80rDEJ4=','2025-12-17 09:53:37.156934',0,'李迎兵','',0,'2025-12-17 09:53:24.660944','JK00661','15290523893','研发部部长','2025-12-17 09:53:25.325506','2025-12-17 09:53:25.325516',2,'admin',1,'',''),(20,'!2ar5VjuuviBkRh60W38dOPpgL6YCJBSomRbyWsGJ',NULL,0,'AnonymousUser','',0,'2026-01-07 07:11:53.396391','','','','2026-01-07 07:11:53.396667','2026-01-07 07:11:53.396676',NULL,'engineer',1,'','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user_permissions`
--

DROP TABLE IF EXISTS `users_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user_permissions`
--

LOCK TABLES `users_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-16  2:00:01
